#imports
import imutils
import time
import datetime
import cv2
import pyttsx3
import threading


# This function plays the audio message
def thread_voice_alert(engine):
    engine.say("Object Detected")
    engine.runAndWait()

def motion_detection():
    video_capture = cv2.VideoCapture(0) # value (0) selects the devices de-fault camera
    time.sleep(2)


baseline_image=None
status_list=[None,None]
video=cv2.VideoCapture(0)

#Setting parameters for voice
engine = pyttsx3.init()
voices = engine.getProperty('voices')
engine.setProperty('voice', voices[1].id)
engine.setProperty('rate', 150)

baseline_image = None  # instinate the first fame

while True:
    check, frame = video.read()
    text = 'Unoccupied'

    status=0
    gray_frame=cv2.cvtColor(frame,cv2.COLOR_BGR2GRAY) # make each frame grey-scale wich is needed for threshold

    gray_frame=cv2.GaussianBlur(gray_frame,(25,25),0)
    # uses a kernel of size(21,21) // has to be an odd number to ensure there is a valid integer in the center
    # and we need to specify the standard deviation in the x and y direction which is the (0) if only x(sigma x) is specified
    # then y(sigma y) is taken as same as x. sigma = standard devia-tion(mathematics term)


    if baseline_image is None:
        baseline_image=gray_frame

        # the first frame is set for background subtraction(BS) using absdiff and then using a threshold to get the foreground mask
        # foreground mask (black background anything that wasn't in the image in the first frame but is in the new frame over the threshold will
        # be a white pixel(white) foreground image is black with the new ob-ject being white...there is your motion detection
    else:
        pass

    frame = imutils.resize(frame, width=500)
    frame_delta = cv2.absdiff(baseline_image, gray_frame)
    # calculates the absolute difference between each element/pixel between the two images, first_frame - greyscale (on each element)

    # edit the ** thresh ** depending on the light/dark in the room, change the 100(anything pixel value over 100 will become 255(white))
    thresh = cv2.threshold(frame_delta, 100, 255, cv2.THRESH_BINARY)[1]
    # threshold gives two outputs retval, threshold image. using [1] on the end I am selecting the threshold image that is produced

    threshold = cv2.dilate(thresh, None, iterations=2)
    # dilate = dilate,grow,expand - the effect on a binary image(black back-ground and white foregorund) is to enlarge/expand the white
    # pixels in the foreground wich are white(255), element=Mat() = default 3x3 kernal matrix and iterartions=2 means it
    # will do it twice

    cnt = cv2.findContours(threshold.copy(), cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)[1]
    # contours gives 3 different output images, contours, and hierarchy, so using [1] on the end means contours = [1](cnt)
    # cv2.CHAIN_APPROX_SIMPLE saves memory by removing all redundant points and compressing the contour, if you have a rectangle
    # with 4 straight lines you don't need to plot each point along the line, you only need to plot the corners of the rectangle
    # and then join the lines, eg instead of having to say 750 points, you have 4 points.... look at the memory you save!

    cnt = cv2.findContours(threshold.copy(), cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)

    for c in cnt[-2]:

        if cv2.contourArea(c) > 800:  # if contour area is less then 800 non-zero(not-black) pixels(white)
            (x, y, w, h) = cv2.boundingRect(c)  # x,y are the top left of the contour and w,h are the width and hieght

            cv2.rectangle(frame, (x, y), (x + w, y + h), (0, 255, 0),
                          2)  # (0, 255, 0) = color R,G,B = lime / 2 = thick-ness(i think?)(YES IM RITE!)
            # image used for the rectangle is frame so that it's on the secu-rity feed image and not the binary/threshold/foreground image
            # as it already used the threshold/(binary image) to find the con-tours this image/frame is what image it will be drawing on

            text = 'Occupied'
            # text that appears when there is motion in the video feed
        else:
            pass

        continue

    delta=cv2.absdiff(baseline_image,gray_frame)
    threshold=cv2.threshold(delta, 30, 255, cv2.THRESH_BINARY)[1]
    (contours,_)=cv2.findContours(threshold,cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)

    for contour in contours:
        if cv2.contourArea(contour) < 10000:
            continue
        status=1
        (x, y, w, h)=cv2.boundingRect(contour)
        cv2.rectangle(frame, (x, y), (x+w, y+h), (0,255,0), 1)
    status_list.append(status)


    if status_list[-1]==1 and status_list[-2]==0:
        t = threading.Thread(target=thread_voice_alert, args=(engine,))
        t.start()

    ''' now draw text and timestamp on the security feed '''
    font = cv2.FONT_HERSHEY_SIMPLEX

    cv2.putText(frame, '{+} Room Status: %s' % (text),
                (10, 20), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 0, 255), 2)
    # frame is the image on which the text will go. 0.5 is size of font, (0,0,255) is R,G,B color of font, 2 on end is LINE THICKNESS! OK :)

    cv2.putText(frame, datetime.datetime.now().strftime('%A %d %B %Y %I:%M:%S%p'),
                (10, frame.shape[0] - 10), cv2.FONT_HERSHEY_SIMPLEX, 0.35, (0, 0, 255),
                1)  # frame.shape[0] = hieght, frame.shape[1] = width,ssssssssssssss
    # using datetime to get date/time stamp, for font positions using frame.shape() wich returns a tuple of (rows,columns,channels)
    # going 10 across in rows/width so need columns with frame.shape()[0] we are selecting columns so however many pixel heights
    # the image is - 10 so opposite end at the bottom instead of being at the top like the other text

    cv2.imshow("gray_frame Frame",gray_frame)
    cv2.imshow("Delta Frame",delta)
    cv2.imshow("Threshold Frame",threshold)
    cv2.imshow("Security Feed",frame)

    key=cv2.waitKey(1)

    key = cv2.waitKey(1) & 0xFF  # (1) = time delay in seconds before execu-tion, and 0xFF takes the last 8 bit to check value or sumin

    if key == ord('q'):
        if status==1:
            cv2.destroyAllWindows()
            times.append(datetime.now())
        break


#Clean up, Free memory
engine.stop()
video.release()
cv2.destroyAllWindows

